<?= $this->extend('Layouts/layout') ?>
<?= $this->section('content') ?>

<?= $this->endSection(); ?>